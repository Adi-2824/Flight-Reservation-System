import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FlightsService } from '../../../services/flights.service';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { BookingService } from '../../../services/booking.service';
import Swal from 'sweetalert2';
import { AuthService } from '../../../services/auth.service';

enum Gender {
  Male = 0,
  Female = 1
}

enum SeatClass {
  Economy = 0,
  Business = 1
}


@Component({
  selector: 'app-booking',
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './booking.component.html',
  styleUrl: './booking.component.css'
})
export class BookingComponent {
  authService = inject(AuthService);
  travellerList:any[] =[];
  flightDetails:any;
  returnFlightDetails:any;
  tripDetails:any;
  flightNumber:any;
  returnFlightNumber:any;
  flightService = inject(FlightsService)
  route = inject(ActivatedRoute);
  router = inject(Router);
  bookingService = inject(BookingService);
  bookingId:any;
  isEditing:boolean = false;

  travellerForm :FormGroup;
  constructor(){
    this.travellerForm = new FormGroup({
       firstName: new FormControl('', [Validators.required]),
    lastName: new FormControl('', [Validators.required]),
    seatClass: new FormControl('Economy', [Validators.required]),
    age: new FormControl('', [Validators.required, Validators.min(1)]),
    gender: new FormControl('', [Validators.required])

    })
  }
  getSeatClassLabel(value: number): string {
  const seatClassMap: Record<number, string> = {
    0: 'Economy',
    1: 'Business'
  };
  return seatClassMap[value] || 'Unknown'; 
  }

  ngOnInit(): void {
    this.travellerList=[];
      this.route.queryParams.subscribe(params=>{
        this.flightNumber=params['flightId'];
         this.returnFlightNumber = params['returnFlightId']; // ✅ Return flight ID (if round-trip)


        this.flightService.getFlightByFlightNumber(this.flightNumber).subscribe({
            next:(data:any)=>{
              console.log(data);
             this.flightDetails = data;
             console.log(this.flightDetails);
              // ✅ Ensure seat availability properties are properly assigned
        this.flightDetails.AvailableEconomySeats = data.availableEconomySeats ?? 0;
        this.flightDetails.AvailableBusinessSeats = data.availableBusinessSeats ?? 0;
        
        console.log("Economy Seats Available:", this.flightDetails.AvailableEconomySeats);
        console.log("Business Seats Available:", this.flightDetails.AvailableBusinessSeats);
            },
            error:(err)=>{
              console.log(err);
            }
        });
        
    if (this.returnFlightNumber) {
      this.flightService.getFlightByFlightNumber(this.returnFlightNumber).subscribe({
        next: (data: any) => {
          this.returnFlightDetails = data;
           this.returnFlightDetails.AvailableEconomySeats = data.availableEconomySeats ?? 0;
          this.returnFlightDetails.AvailableBusinessSeats = data.availableBusinessSeats ?? 0;
        },
        error: (err) => {
          console.log(err);
        }
      });
    }
  });
}

   calculateTotalFare(): number {
  let totalFare = 0;

  // Ensure outbound flight details exist
  if (!this.flightDetails) {
    console.error("Outbound flight details missing, unable to calculate fare.");
    return totalFare;
  }

  // Calculate fare for outbound flight
  this.travellerList.forEach(traveller => {
    const outboundPrice = traveller.seatClass === SeatClass.Economy ? this.flightDetails.economyPrice : this.flightDetails.businessPrice;
    totalFare += outboundPrice;
  });

  // If round-trip, calculate return flight fare separately
  if (this.returnFlightNumber && this.returnFlightDetails) {
    this.travellerList.forEach(traveller => {
      const returnPrice = traveller.seatClass === SeatClass.Economy ? this.returnFlightDetails.economyPrice : this.returnFlightDetails.businessPrice;
      totalFare += returnPrice;
    });
  }

  return totalFare;
}

editTraveller(traveller: any) {
  this.isEditing = true;
  this.travellerForm.patchValue({
    id: traveller.id,
    firstName: traveller.firstName,
    lastName: traveller.lastName,
    age: traveller.age,
    gender: traveller.gender === 1?"Female":"Male",
    seatClass: traveller.seatClass === 1 ? "Business" : "Economy" // ✅ Ensure correct mapping
  });
}



  addTraveller(){
    if(this.travellerForm.invalid){
        Swal.fire({
      title: "Incomplete Traveler Details!",
      text: "Please fill all required fields before adding a traveler.",
      icon: "warning",
      confirmButtonText: "OK"
    });

      return;
    }
    const seatClass = this.travellerForm.get('seatClass')?.value;
      const economyPassengers = this.travellerList.filter(t => t.seatClass === SeatClass.Economy).length;
  const businessPassengers = this.travellerList.filter(t => t.seatClass === SeatClass.Business).length;
 console.log("Checking seat availability...");
  console.log("Economy seats left:", this.flightDetails.AvailableEconomySeats);
  console.log("Economy passengers:", economyPassengers);
  console.log("Business seats left:", this.flightDetails.AvailableBusinessSeats);
  console.log("Business passengers:", businessPassengers);


// ✅ Check seat availability before adding traveler
  if (seatClass === 'Economy' && this.flightDetails.AvailableEconomySeats <= economyPassengers) {
    Swal.fire({
      title: "Not Enough Economy Seats!",
      text: "The flight is full for economy class. Please try another seat class or flight.",
      icon: "error",
      confirmButtonText: "OK"
    });
    return; // ✅ Prevent traveler from being added
  }

if (seatClass === 'Business' && this.flightDetails.AvailableBusinessSeats <= businessPassengers) {
    Swal.fire({
      title: "Not Enough Business Seats!",
      text: "The flight is full for business class. Please try another seat class or flight.",
      icon: "error",
      confirmButtonText: "OK"
    });
    return; // ✅ Prevent traveler from being added
  }

  const price = seatClass === 'Economy' ? this.flightDetails.economyPrice : this.flightDetails.businessPrice;


    const updatedTraveller ={
    id: this.travellerForm.get('id')?.value,
    firstName: this.travellerForm.get('firstName')?.value,
    lastName: this.travellerForm.get('lastName')?.value,
    seatClass: SeatClass[this.travellerForm.get('seatClass')?.value as keyof typeof SeatClass],
    price:price,
    age:this.travellerForm.get('age')?.value ,
    gender:Gender[this.travellerForm.get('gender')?.value as keyof typeof Gender]
    }
     console.log("New Traveller Added:", updatedTraveller); 
     
    const index = this.travellerList.findIndex(t => t.id === updatedTraveller.id);
  
  if (index !== -1) {
    this.travellerList[index] = updatedTraveller; // ✅ Update existing traveler
  } else {
    this.travellerList.push(updatedTraveller); // ✅ Add new traveler
  }

  this.isEditing = false;
  this.travellerForm.reset();

  }

  ProceedToBooking() {
    console.log("🚀 ProceedToBooking function triggered!");


    if (!this.authService.getToken()) {
      localStorage.setItem("lastPage",this.router.url);
      Swal.fire({
        title: "Login Required",
        text: "You need to log in before proceeding to payment.",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Log In",
        cancelButtonText: "Cancel"
      }).then((result) => {
        if (result.isConfirmed) {
          this.router.navigate(['/dashboard/login']); // Redirect to login page
        }
      });
      return;
    }


  if (!this.travellerList.length) {
    Swal.fire("Please add travellers before proceeding.");
    return;
  }
  if (!this.flightNumber) {
    console.error("Error: Outbound flight number is undefined.");
    return;
  }

  // ✅ Check seat availability before proceeding
  const economyPassengers = this.travellerList.filter(t => t.seatClass === SeatClass.Economy).length;
  const businessPassengers = this.travellerList.filter(t => t.seatClass === SeatClass.Business).length;

if (this.flightDetails.AvailableEconomySeats < economyPassengers) {
    Swal.fire({
      title: "Not Enough Seats!",
      text: "There are not enough economy seats available for your selection. Please try another flight.",
      icon: "error",
      confirmButtonText: "OK"
    });
    return;
  }

 if (this.flightDetails.AvailableBusinessSeats < businessPassengers) {
    Swal.fire({
      title: "Not Enough Business Seats!",
      text: "There are not enough business seats available. Please try another flight.",
      icon: "error",
      confirmButtonText: "OK"
    });
    return;
  }


  const outboundBookingData = {
    flightId: this.flightNumber, // ✅ Outbound flight ID
    passengers: this.travellerList // ✅ Passenger list
  };

  console.log("Booking outbound flight:", outboundBookingData);

  // ✅ First API Call: Book Outbound Flight

  this.bookingService.bookTickets(outboundBookingData.flightId,outboundBookingData.passengers)?.subscribe({
    next: (reservation: any) => {
      console.log("Outbound flight booked:", reservation);
      
      // ✅ If round-trip, make second API call for return flight
      if (this.returnFlightNumber) {
        const returnBookingData = {
          flightId: this.returnFlightNumber, // ✅ Return flight ID
          passengers: this.travellerList // ✅ Same passengers for return flight
        };

        console.log("Booking return flight:", returnBookingData);

        this.bookingService.bookTickets(returnBookingData.flightId,returnBookingData.passengers)?.subscribe({
          next: (returnReservation: any) => {
            console.log("Return flight booked:", returnReservation);

            const totalFare = this.calculateTotalFare(); // ✅ Calculate total cost
            console.log("Total Fare for Round Trip:", totalFare);

            // ✅ Navigate to confirmation with both reservation IDs
            Swal.fire({
              title: "Round Trip Booking Confirmed!",
              text: `Total Fare: ₹${totalFare}`,
              icon: "success",
              timer: 2000,
              showConfirmButton: false
            }).then(() => {
              this.router.navigate(['/booking-confirmation'], { 
                queryParams: { reservationId: reservation.id, returnReservationId: returnReservation.id }
              });
            });
          },
          error: (err: any) => {
            console.error("Error booking return flight:", err);
          }
        });
      } else {
        // ✅ Navigate to confirmation for one-way booking
        const totalFare = this.calculateTotalFare();
        console.log("Total Fare for One-Way:", totalFare);

        Swal.fire({
          title: "Booking Confirmed!",
          text: `Total Fare: ₹${totalFare}`,
          icon: "success",
          timer: 2000,
          showConfirmButton: false
        }).then(() => {
          this.router.navigate(['/booking-confirmation'], { queryParams: { reservationId: reservation.id } });
        });
      }
    },
    error: (err: any) => {
      console.error("Error booking outbound flight:", err);
    }
  });
}
  }


