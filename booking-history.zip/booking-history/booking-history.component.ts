import { Component, inject } from '@angular/core';
import { BookingService } from '../../../services/booking.service';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Dropdown } from 'bootstrap';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-booking-history',
  imports: [CommonModule],
  templateUrl: './booking-history.component.html',
  styleUrls: ['./booking-history.component.css']
})
export class BookingHistoryComponent {
  bookingService = inject(BookingService);
  router = inject(Router);
  bookingList: any[] = [];
  filteredBookingList: any[] = []; // Data displayed after filtering
  

  ngOnInit() {
      this.checkExpiredReservations(); 
    this.fetchAllReservations(); 
    // Load all reservations by default
   setTimeout(() => {
    document.querySelectorAll('.dropdown-toggle').forEach(dropdown => {
      new Dropdown(dropdown);
    });
  }, 100);


  }

  checkExpiredReservations() {
  this.bookingService.checkExpiredReservations().subscribe({
    next: (res: any) => {
      console.log(res);
      console.log(`Expired reservations updated: ${res.updatedCount}`);
    },
    error: (err) => {
      console.error("Error checking expired reservations:", err);
    }
  });
}

  filterBookings(type: string) {
  const now = new Date();

  if (type === 'all') {
    this.filteredBookingList = [...this.bookingList]; // Show all reservations
  } else if (type === 'upcoming') {
    this.filteredBookingList = this.bookingList.filter(
      (booking) => new Date(booking.flight.departureDateTime) > now
    );
  } else if (type === 'past') {
    this.filteredBookingList = this.bookingList.filter(
      (booking) => new Date(booking.flight.departureDateTime) < now
    );
  }

  console.log(`Filtered ${type} journeys:`, this.filteredBookingList);
}


filterByStatus(status: string) {
  if (status === 'all') {
     this.filteredBookingList = [...this.bookingList];
  }
  else{
    this.filteredBookingList = this.bookingList.filter((booking) => {
    return (
      (status === 'pending' && booking.status === 0) ||
      (status === 'confirmed' && booking.status === 1) ||
      (status === 'cancelled' && booking.status === 2) ||
      (status === 'refunded' && booking.status === 3)
    );
  });
  }
  console.log(`Filtered reservations by status: ${status}`, this.filteredBookingList);
   // ✅ Force Angular to detect changes
  setTimeout(() => {}, 0);

}

  fetchAllReservations() {
    this.bookingService.getUserBookings().subscribe({
      next: (data: any) => {
        console.log("All Reservations:", data);
        this.bookingList = data.map((booking: any)=>({
          ...booking,
          returnReservationId:this.findReturnReservation(booking,data),
         isExpired: new Date(booking.expiresAt) < new Date() 


        }))
        this.filteredBookingList = this.bookingList; // Show all reservations initially
      },
      error: (err) => {
        console.error("Error fetching reservations:", err);
      }
    });
  }

  findReturnReservation(outboundBooking: any, allBookings: any[]): number | undefined {
     if (!allBookings || allBookings.length === 0) {
    return undefined; // ✅ Prevents errors if booking list is empty
  }


  return allBookings.find(
    booking => booking.flight.origin === outboundBooking.flight.destination &&
               booking.flight.destination === outboundBooking.flight.origin &&
               new Date(booking.bookingDate) > new Date(outboundBooking.bookingDate) &&
               booking.passengers.length === outboundBooking.passengers.length
  )?.id || undefined;
}
  cancelRoundTrip(reservationId: number, returnReservationId?: number) {
   

  Swal.fire({
    title: "Cancel Roundtrip?",
    text: "Are you sure you want to cancel both reservations?",
    icon: "warning",
    showCancelButton: true,
    confirmButtonText: "Yes, Cancel Both",
    cancelButtonText: "No, Keep My Booking"
  }).then((result) => {
    if (result.isConfirmed) {
      const cancelRequests = [this.bookingService.cancelReservation(reservationId)];
      if (returnReservationId) {
        cancelRequests.push(this.bookingService.cancelReservation(returnReservationId));
      }
      

      Promise.all(cancelRequests.map(req => req.toPromise())).then(() => {
        Swal.fire("Roundtrip Cancelled!", "Both tickets have been cancelled successfully.", "success");
        this.fetchAllReservations(); // ✅ Refresh UI after cancellation
      }).catch((err) => {
        console.error("Error cancelling roundtrip:", err);
        Swal.fire("Cancellation Failed", "Could not cancel roundtrip booking.", "error");
      });
    }
  });
}


payForRoundTrip(booking: any) {
  const returnReservationId = this.findReturnReservation(booking, this.bookingList);

  if (!returnReservationId && booking.status !== 0) {
    alert("Payment only available for pending reservations.");
    return;
  }

  Swal.fire({
    title: "Proceed to Payment?",
    text: "You are about to pay for your roundtrip booking.",
    icon: "info",
    showCancelButton: true,
    confirmButtonText: "Proceed to Payment",
    cancelButtonText: "Cancel"
  }).then((result) => {
    if (result.isConfirmed) {
      this.router.navigate(['/payment'], { 
        queryParams: { reservationId: booking.id, returnReservationId } 
      });
    }
  });
}


  fetchUpcomingJourneys() {
    this.bookingService.getUpcomingJourneys().subscribe({
      next: (data: any[]) => {
        console.log("Upcoming Journeys:", data);
        this.filteredBookingList = this.formatBookings(data);
      },
      error: (err) => {
        console.error("Error fetching upcoming journeys:", err);
      }
    });
  }

  fetchPastJourneys() {
    this.bookingService.getPastJourneys().subscribe({
      next: (data: any[]) => {
        console.log("Past Journeys:", data);
        this.filteredBookingList = this.formatBookings(data);
      },
      error: (err) => {
        console.error("Error fetching past journeys:", err);
      }
    });
  }

  formatBookings(data: any[]): any[] {
    return data.map(booking => ({
      ...booking,
      bookingDate: booking.bookingDate ? new Date(booking.bookingDate) : 'N/A',
      flight: {
        ...booking.flight,
        departureDateTime: booking.flight.departureDateTime ? new Date(booking.flight.departureDateTime) : 'N/A',
        arrivalDateTime: booking.flight.arrivalDateTime ? new Date(booking.flight.arrivalDateTime) : 'N/A',
      },
      passengers: booking.passengers ?? []
    }));
  }

  moreDetails(id:number) {
    console.log("Show more details logic here");
    this.router.navigate(["/booking-information",id]);
  }
}

// import { Component, inject } from '@angular/core';
// import { BookingService } from '../../../services/booking.service';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-booking-history',
//   imports: [CommonModule],
//   templateUrl: './booking-history.component.html',
//   styleUrls: ['./booking-history.component.css']
// })
// export class BookingHistoryComponent {
//   bookingService = inject(BookingService);
//   bookingList: any[] = []; // Original unfiltered data
//   filteredBookingList: any[] = []; // Data displayed after filtering

//   ngOnInit() {
//     this.fetchBookingHistory(); // Load all bookings by default
//   }

//   fetchBookingHistory() {
//     this.bookingService.getUserBookings().subscribe({
//       next: (data: any) => {
//         console.log("Fetched Data:", data);
//         this.bookingList = this.formatBookings(data);
//         this.filteredBookingList = [...this.bookingList]; // Initially show all reservations
//       },
//       error: (err) => {
//         console.error("Error fetching booking history:", err);
//       }
//     });
//   }

//   formatBookings(data: any[]): any[] {
//     return data.map((booking) => ({
//       ...booking,
//       bookingDate: booking.bookingDate ? new Date(booking.bookingDate) : 'N/A',
//       flight: {
//         ...booking.flight,
//         departureDateTime: booking.flight.departureDateTime ? new Date(booking.flight.departureDateTime) : 'N/A',
//         arrivalDateTime: booking.flight.arrivalDateTime ? new Date(booking.flight.arrivalDateTime) : 'N/A',
//       },
//       passengers: booking.passengers ?? []
//     }));
//   }

//   filterBookings(type: string) {
//     const now = new Date();

//     if (type === 'all') {
//       this.filteredBookingList = [...this.bookingList]; // Show all reservations
//     } else if (type === 'upcoming') {
//       this.filteredBookingList = this.bookingList.filter(
//         (booking) => new Date(booking.flight.departureDateTime) > now
//       );
//     } else if (type === 'past') {
//       this.filteredBookingList = this.bookingList.filter(
//         (booking) => new Date(booking.flight.departureDateTime) < now
//       );
//     }

//     console.log(`Filtered ${type} journeys:`, this.filteredBookingList);
//   }

//   moreDetails() {
//     console.log("Show more details logic here");
//   }
// }