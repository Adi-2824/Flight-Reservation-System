﻿using System.ComponentModel.DataAnnotations;
using AirTicketBackend.Models.Flight_Models;

namespace AirTicketBackend.Models.Airline_Models
{
    public class AirlineDbModel
    {
        [Key]
        public int AirlineId { get; set; }
        public string? Name { get; set; }
        public string? Code { get; set; }
        public string? Country { get; set; }

        public ICollection<FlightDBModel>? Flights { get; set; }
    }
}
