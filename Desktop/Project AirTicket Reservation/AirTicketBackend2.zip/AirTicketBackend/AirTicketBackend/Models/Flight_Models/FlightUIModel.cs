﻿namespace AirTicketBackend.Models.Flight_Models
{
    public class FlightUIModel
    {
        public string? FlightNumber { get; set; }
        public string? AirlineName { get; set; }
        public string? FromCity { get; set; }
        public string? ToCity { get; set; }
        public DateTime DepartureDate { get; set; }
        public TimeSpan DepartureTime { get; set; }
        public TimeSpan ArrivalTime { get; set; }
        public string? Status { get; set; }
        public decimal? Price { get; set; }
    }
}
