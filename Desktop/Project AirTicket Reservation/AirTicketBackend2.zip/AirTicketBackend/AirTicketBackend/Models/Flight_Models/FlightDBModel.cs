﻿using System.ComponentModel.DataAnnotations;
using AirTicketBackend.Models.AirField_Models;
using AirTicketBackend.Models.Airline_Models;

namespace AirTicketBackend.Models.Flight_Models
{
    public class FlightDBModel
    {
        [Key]
        public int FlightId { get; set; }
        public string? FlightNumber { get; set; }
        public int AirlineId { get; set; }
        public int DepartureAirportId { get; set; }
        public int ArrivalAirportId { get; set; }
        public DateTime DepartureDate { get; set; }
        public TimeSpan DepartureTime { get; set; }
        public TimeSpan ArrivalTime { get; set; }
        public TimeSpan? Duration { get; set; }
        public string Status { get; set; } = "Scheduled";

        public AirlineDbModel? Airline { get; set; }
        public AirFieldDBModel? DepartureAirport { get; set; }
        public AirFieldDBModel? ArrivalAirport { get; set; }
    }
}
