﻿namespace AirTicketBackend.Models.Flight_Models
{
    public class UpdateFlightUIModel : CreateFlightUIModel
    {
        public int FlightId { get; set; }
    }
}
