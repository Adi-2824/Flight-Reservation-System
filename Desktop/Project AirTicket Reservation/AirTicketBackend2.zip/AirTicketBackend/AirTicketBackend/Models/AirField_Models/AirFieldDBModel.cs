﻿using System.ComponentModel.DataAnnotations;
using AirTicketBackend.Models.Flight_Models;

namespace AirTicketBackend.Models.AirField_Models
{
    public class AirFieldDBModel
    {
        [Key]
        public int AirportId { get; set; }
        public string? Name { get; set; }
        public string? City { get; set; }
        public string? Country { get; set; }
        public string? Code { get; set; }

        public ICollection<FlightDBModel>? DepartingFlights { get; set; }
        public ICollection<FlightDBModel>? ArrivingFlights { get; set; }
    }
}
