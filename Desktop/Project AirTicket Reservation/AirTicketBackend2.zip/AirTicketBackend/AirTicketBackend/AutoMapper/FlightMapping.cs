﻿using AirTicketBackend.Models.Flight_Models;
using AutoMapper;

namespace AirTicketBackend.AutoMapper
{
    public class FlightMapping:Profile
    {
        public FlightMapping()
        {
            CreateMap<FlightDBModel, FlightUIModel>()
           .ForMember(dest => dest.AirlineName, opt => opt.MapFrom(src => src.Airline.Name ))
           .ForMember(dest => dest.FromCity, opt => opt.MapFrom(src => src.DepartureAirport.City))
           .ForMember(dest => dest.ToCity, opt => opt.MapFrom(src => src.ArrivalAirport.City));

            CreateMap<CreateFlightUIModel, FlightDBModel>().ReverseMap();
            CreateMap<UpdateFlightUIModel, FlightDBModel>().ReverseMap();
        }
    }
}
