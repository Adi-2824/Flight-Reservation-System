﻿//using AirTicketBackend.Models.AirField_Models;
//using AirTicketBackend.Models.Airline_Models;
//using AirTicketBackend.Models.Flight_Models;
//using Microsoft.EntityFrameworkCore;


//namespace AirTicketBackend.DataAccessLayer
//{
//    public class AppDbContext:DbContext
//    {
//        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

//        public DbSet<FlightDBModel> Flights { get; set; }
//        public DbSet<AirlineDbModel> Airlines { get; set; }
//        public DbSet<AirFieldDBModel> Airports { get; set; }

//        protected override void OnModelCreating(ModelBuilder modelBuilder)
//        {
//            modelBuilder.Entity<FlightDBModel>()
//                .HasOne(f => f.Airline)
//                .WithMany(a => a.Flights)
//                .HasForeignKey(f => f.AirlineId);

//            modelBuilder.Entity<FlightDBModel>()
//                .HasOne(f => f.DepartureAirport)
//                .WithMany(a => a.DepartingFlights)
//                .HasForeignKey(f => f.DepartureAirportId)
//                .OnDelete(DeleteBehavior.Restrict);

//            modelBuilder.Entity<FlightDBModel>()
//                .HasOne(f => f.ArrivalAirport)
//                .WithMany(a => a.ArrivingFlights)
//                .HasForeignKey(f => f.ArrivalAirportId)
//                .OnDelete(DeleteBehavior.Restrict);
//        }
//    }
//}


using AirTicketBackend.Models.AirField_Models;
using AirTicketBackend.Models.Airline_Models;
using AirTicketBackend.Models.Flight_Models;
using Microsoft.EntityFrameworkCore;

namespace AirTicketBackend.DataAccessLayer
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<FlightDBModel> Flights { get; set; }
        public DbSet<AirlineDbModel> Airlines { get; set; }
        public DbSet<AirFieldDBModel> Airports { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Define relationships
            modelBuilder.Entity<FlightDBModel>()
                .HasOne(f => f.Airline)
                .WithMany(a => a.Flights)
                .HasForeignKey(f => f.AirlineId);

            modelBuilder.Entity<FlightDBModel>()
                .HasOne(f => f.DepartureAirport)
                .WithMany(a => a.DepartingFlights)
                .HasForeignKey(f => f.DepartureAirportId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<FlightDBModel>()
                .HasOne(f => f.ArrivalAirport)
                .WithMany(a => a.ArrivingFlights)
                .HasForeignKey(f => f.ArrivalAirportId)
                .OnDelete(DeleteBehavior.Restrict);

            // **Seed Data for Airlines**
            modelBuilder.Entity<AirlineDbModel>().HasData(
                new AirlineDbModel { AirlineId = 1, Name = "IndiGo Airlines", Code = "6E", Country = "India" },
                new AirlineDbModel { AirlineId = 2, Name = "Air India", Code = "AI", Country = "India" },
                new AirlineDbModel { AirlineId = 3, Name = "SpiceJet", Code = "SG", Country = "India" },
                new AirlineDbModel { AirlineId = 4, Name = "Emirates", Code = "EK", Country = "UAE" },
                new AirlineDbModel { AirlineId = 5, Name = "Qatar Airways", Code = "QR", Country = "Qatar" }
            );

            // **Seed Data for Airports**
            modelBuilder.Entity<AirFieldDBModel>().HasData(
                new AirFieldDBModel { AirportId = 1, Name = "Indira Gandhi International Airport", City = "Delhi", Country = "India", Code = "DEL" },
                new AirFieldDBModel { AirportId = 2, Name = "Chhatrapati Shivaji Maharaj International Airport", City = "Mumbai", Country = "India", Code = "BOM" },
                new AirFieldDBModel { AirportId = 3, Name = "Dubai International Airport", City = "Dubai", Country = "UAE", Code = "DXB" },
                new AirFieldDBModel { AirportId = 4, Name = "Hamad International Airport", City = "Doha", Country = "Qatar", Code = "DOH" }
            );
        }
    }
}