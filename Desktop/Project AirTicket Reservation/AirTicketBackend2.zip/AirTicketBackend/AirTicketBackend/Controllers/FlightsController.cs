﻿using AirTicketBackend.Models.Flight_Models;
using AirTicketBackend.Repository.Flight_Repo;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AirTicketBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FlightsController : ControllerBase
    {
        private readonly IFlightRepository _repository;
        private readonly IMapper _mapper;

        public FlightsController(IFlightRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var flights = await _repository.GetAllAsync();
            var result = _mapper.Map<IEnumerable<FlightUIModel>>(flights);
            return Ok(result);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var flight = await _repository.GetByIdAsync(id);
            if (flight == null) return NotFound();
            return Ok(_mapper.Map<FlightUIModel>(flight));
        }

        [HttpGet("search")]
        public async Task<IActionResult> Search([FromQuery] string from, [FromQuery] string to, [FromQuery] DateTime date)
        {
            var flights = await _repository.SearchAsync(from, to, date);
            var result = _mapper.Map<IEnumerable<FlightUIModel>>(flights);
            return Ok(result);
        }

        //[HttpPost]
        //public async Task<IActionResult> Create([FromBody] FlightDBModel flight)
        //{
        //    await _repository.AddAsync(flight);
        //    return CreatedAtAction(nameof(Get), new { id = flight.FlightId }, flight);
        //}

        //[HttpPut("{id}")]
        //public async Task<IActionResult> Update(int id, [FromBody] FlightDBModel updated)
        //{
        //    if (id != updated.FlightId) return BadRequest();
        //    await _repository.UpdateAsync(updated);
        //    return NoContent();
        //}

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _repository.DeleteAsync(id);
            return NoContent();
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateFlightUIModel dto)
        {
            var flight = _mapper.Map<FlightDBModel>(dto);
            await _repository.AddAsync(flight);
            return CreatedAtAction(nameof(Get), new { id = flight.FlightId }, _mapper.Map<FlightUIModel>(flight)); // 
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateFlightUIModel dto)
        {
            if (id != dto.FlightId) return BadRequest("Flight ID mismatch");
            var flight = _mapper.Map<FlightDBModel>(dto);
            await _repository.UpdateAsync(flight);
            return Ok("Flight updated successfully");
        }

        
    }
}
