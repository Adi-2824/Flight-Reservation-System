﻿using AirTicketBackend.Models.Flight_Models;

namespace AirTicketBackend.Repository.Flight_Repo
{
    public interface IFlightRepository
    {
        Task<IEnumerable<FlightDBModel>> GetAllAsync();
        Task<FlightDBModel?> GetByIdAsync(int id);
        Task<IEnumerable<FlightDBModel>> SearchAsync(string fromCity, string toCity, DateTime date);
        Task AddAsync(FlightDBModel flight);
        Task UpdateAsync(FlightDBModel flight);
        Task DeleteAsync(int id);
    }
}
