﻿using AirTicketBackend.DataAccessLayer;
using AirTicketBackend.Models.Flight_Models;
using Microsoft.EntityFrameworkCore;

namespace AirTicketBackend.Repository.Flight_Repo
{
    public class FlightRepository:IFlightRepository
    {
        private readonly AppDbContext _context;

        public FlightRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<FlightDBModel>> GetAllAsync()
        {
            return await _context.Flights.Include(f => f.Airline)
                                          .Include(f => f.DepartureAirport)
                                          .Include(f => f.ArrivalAirport)
                                          .ToListAsync();
        }

        public async Task<FlightDBModel?> GetByIdAsync(int id)
        {
            return await _context.Flights.Include(f => f.Airline)
                                         .Include(f => f.DepartureAirport)
                                         .Include(f => f.ArrivalAirport)
                                         .FirstOrDefaultAsync(f => f.FlightId == id);
        }

        public async Task<IEnumerable<FlightDBModel>> SearchAsync(string fromCity, string toCity, DateTime date)
        {
            return await _context.Flights
                .Include(f => f.DepartureAirport)
                .Include(f => f.ArrivalAirport)
                .Include(f => f.Airline)
                .Where(f => f.DepartureAirport.City == fromCity &&
                            f.ArrivalAirport.City == toCity &&
                            f.DepartureDate == date)
                .ToListAsync();
        }

        public async Task AddAsync(FlightDBModel flight)
        {
            await _context.Flights.AddAsync(flight);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(FlightDBModel flight)
        {
            _context.Flights.Update(flight);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var flight = await _context.Flights.FindAsync(id);
            if (flight != null)
            {
                _context.Flights.Remove(flight);
                await _context.SaveChangesAsync();
            }
        }
    }
}
